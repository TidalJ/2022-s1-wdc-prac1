var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/brew', (req,res) => {
  // res.send(req.query.drink)
  var q = req.query.drink;
  // res.send(q)
  if(q == 'tea')
    res.send('A delicious cup of tea!');
  else if(q == 'coffee')
    res.status(418).send('i am a teapot');
  else
    res.status(400).send('Bad Request');

})

var count = 0;
var lastText = '';
router.post('/pass-it-on',(req,res) => {

  var text = req.body.message;
  if(text === undefined )
    res.sendStatus(400);
  else if(count === 0)
    res.send('first')
  else
    res.send(lastText)
  count++;
  lastText = text;
})

// var suf = [];
// var finalText = '';
// var num = 0;
// router.post('/combine',(req,res) => {
//   var temp = req.body.lines;
//   suf[num] = req.body.suffix;
//   finalText = finalText + temp + suf[num] ;
//   // console.log(temp);

//   res.send(finalText);
//   num ++;
// })

router.post('/combine', (req, res, next) => {
  var suf = req.body.suffix;
  var result = "";
  for (var i=0;i<req.body.lines.length;i++){
    result = result + req.body.lines[i] + suf + '\n';
  }
  res.send(result);
});



router.get('/cookie',(req,res) => {
  if("task3_1" in req.cookies === false || req.cookies === null){
    res.cookie("task3_1",'1');
    res.send('new');
  }
  else{
    var first = Number(req.cookies.task3_1);
    first++;
    res.cookie("task3_1", first.toString(10));
    res.send('update');
  }
});


// router.post('/tcaccept',(req,res) => {
//   req.session.variableName = 5;
//   console.log(req.session.variableName);
//   res.send("It works");
// });

// router.get('/users/accepted',(req,res) => {
//   // if(req.session.variableName != 5)
//   //   res.sendStatus(403);
//   // else
//   //   res.send('It works');
//   console.log(req.session.variableName);
//   res.send(req.session.variableName);
// });

module.exports = router;
