SELECT last_name,first_name FROM actor
	ORDER BY last_name,first_name;